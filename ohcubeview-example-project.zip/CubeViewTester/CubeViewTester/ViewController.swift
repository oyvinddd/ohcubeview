//
//  ViewController.swift
//  CubeViewTester
//
//  Created by Øyvind Hauge on 28/09/16.
//  Copyright © 2016 Oyvind Hauge. All rights reserved.
//

import UIKit
import OHCubeView

class ViewController: UIViewController {

    @IBOutlet weak var cubeView: OHCubeView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create subviews for our cube view (in this case, five image views)
        
        let iv1 = UIImageView(image: UIImage(named: "img1"))
        let iv2 = UIImageView(image: UIImage(named: "img2"))
        let iv3 = UIImageView(image: UIImage(named: "img3"))
        let iv4 = UIImageView(image: UIImage(named: "img4"))
        let iv5 = UIImageView(image: UIImage(named: "img5"))
        
        // Ad the subview to the cube view
        
        cubeView.addChildViews([iv1, iv2, iv3, iv4, iv5])
    }
}
